//initial landing page
import React from 'react';
import Button from '../components/form/Button';
import { Link } from "react-router-dom";
import "./assets/css/Page.css";



let wow = () => {
    console.log("truth")
}

let Home = () => {
    
    return (
        <div>

            <Link to="/play">
            <Button
                title="PLAY"
                onClick={wow}
                />
                </Link>
                <Link to="/create">
            <Button
                title="CREATE"
                onClick={wow}
                />
                </Link>
        </div>
    )
};

export default Home;